-- =============================================
-- Author:		319
-- Create date: 2019-07-04
-- Description:	从分表存储的门诊处方数据中抽取到本地库中、本地库中将带有补传标志的数据补传到业务库中、删除本地库中用于缓存的数据
-- =============================================
CREATE PROCEDURE Prog_Pipe_FJZL_Prescription(
	@KH varchar(32),
	@Month varchar(8),
	@Flag char(1),
	@Result char(1) Output
)AS
BEGIN
	SET NOCOUNT ON;
	Declare @SQL nvarchar(Max);

	--将分表保存的门诊处方表中的数据同步到本地,用于判断是否需要同步到业务库中
	If(@Flag='1')
    Begin
		Begin Try
			Set @SQL=
			'Insert Into TB_CIS_Prescription_Detail(CYH,CFMXH,YLJGDM,WSJGDM,JZLSH,CXBZ,KH,KLX,JZKSDM,KFYS,
				KFYSXM,KFYSSFZ,KFRQ,XMBM,XMBMYB,SCPH,YXQZ,XMMC,CFLX,JXDM,YPGG,YPYF,YPSL,YPDW,CFTS,YZZH,
				SYPCDM,SYPC,JL,DW,MCSL,MCDW,YF,YYTS,JYDM,SFPS,JCBW,BZ,MJ,BCBZ)
			Select CYH,CFMXH,YLJGDM,WSJGDM,JZLSH,CXBZ,KH,KLX,JZKSDM,KFYS,KFYSXM,KFYSSFZ,KFRQ,XMBM,XMBMYB,
				SCPH,YXQZ,XMMC,CFLX,JXDM,YPGG,YPYF,YPSL,YPDW,CFTS,YZZH,SYPCDM,SYPC,JL,DW,MCSL,MCDW,YF,
				YYTS,JYDM,SFPS,JCBW,BZ,MJ,''0''
			From TB_CIS_Prescription_Detail_V21_'+Left(@Month,6)+'01 A 
			Where A.KH=@KH 
				And Not Exists(Select 1 From TB_CIS_Prescription_Detail B 
					Where A.CYH=B.CYH And A.CFMXH=B.CFMXH And A.Yljgdm=B.Yljgdm);';
			Exec SP_Executesql @SQL,N'@KH nvarchar(32)',@KH;
			Set @Result='1';
		End Try
		Begin Catch
			Set @Result='0';
		End Catch
	End

	--将本地保存的，有补传标志的数据，补传到对应的业务库中
	If(@Flag='2')
	Begin
		Begin Try
			Declare @startDate Datetime=Convert(Datetime,Left(@Month,6)+'01',121);
			Declare @endDate Datetime=Dateadd(SS,-1,Dateadd(MM,1,@startDate));
			Set @SQL
			='Insert Into TB_CIS_Prescription_Detail_V21(CYH,CFMXH,YLJGDM,WSJGDM,JZLSH,CXBZ,KH,KLX,JZKSDM,
				KFYS,KFYSXM,KFYSSFZ,KFRQ,XMBM,XMBMYB,SCPH,YXQZ,XMMC,CFLX,JXDM,YPGG,YPYF,YPSL,YPDW,CFTS,
				YZZH,SYPCDM,SYPC,JL,DW,MCSL,MCDW,YF,YYTS,JYDM,SFPS,JCBW,BZ,MJ)
			Select CYH,CFMXH,YLJGDM,WSJGDM,JZLSH,CXBZ,KH,KLX,JZKSDM,KFYS,KFYSXM,KFYSSFZ,KFRQ,XMBM,XMBMYB,
				SCPH,YXQZ,XMMC,CFLX,JXDM,YPGG,YPYF,YPSL,YPDW,CFTS,YZZH,SYPCDM,SYPC,JL,DW,MCSL,MCDW,YF,YYTS,
				JYDM,SFPS,JCBW,BZ,MJ
			From TB_CIS_Prescription_Detail A
			Where KH=@KH And KFRQ Between @KSSJ And @JSSJ And BCBZ=''1''
				And Not Exists(Select 1 From TB_CIS_Prescription_Detail_V21 B
					Where A.CYH=B.CYH And A.CFMXH=B.CFMXH And A.YLJGDM=B.YLJGDM);';
			Exec SP_Executesql @SQL,N'@KH varchar(32),@KSSJ Datetime,@JSSJ Datetime',@KH,@startDate,@endDate;
			print Error_Message();
			Set @Result='1';
		End Try
		Begin Catch
			Set @Result='0';
		End Catch
		If(@Result='1') Exec Prog_Pipe_FJZL_Prescription @KH,@Month,'3','';
	End

	--清空本次同步到本地的处方数据
	If(@Flag='3')
	Begin
		Begin Try
			Delete TB_CIS_Prescription_Detail 
			Where KH=@KH And KFRQ Between Convert(Datetime,Left(@Month,6)+'01',121) 
				And DATEADD(SS,-1,Dateadd(MM,1,Left(@Month,6)+'01'));
			Set @Result='1';
			If(Select Count(1) From TB_CIS_Prescription_Detail)=0 Truncate Table TB_CIS_Prescription_Detail;
		End Try
		Begin Catch
			Set @Result='0';
		End Catch
	ENd
END
GO
