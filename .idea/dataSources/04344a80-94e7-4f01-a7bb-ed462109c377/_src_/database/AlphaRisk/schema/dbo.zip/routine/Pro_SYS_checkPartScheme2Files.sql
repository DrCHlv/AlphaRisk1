-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- Exec Pro_SYS_checkPartScheme2Files '20180501';
-- =============================================
CREATE PROCEDURE [dbo].[Pro_SYS_checkPartScheme2Files](
	@Date VARCHAR(8)
)AS
BEGIN
	SET NOCOUNT ON;
	IF ISDATE(@Date)=0 RETURN;SET @Date=LEFT(@Date,6)+'01';

	DECLARE @SQL VARCHAR(MAX);

	--1.从系统中获取数据库文件名与数据库文件组名,用于判断当前日期是否需要新建数据库文件与文件组
	DECLARE @database_FileName varchar(5)=(
		select isnull(max(replace(name,'AlphaRisk_','')),'01800') from sys.database_files 
		where type='0' and type_desc='ROWS' and file_id>1);

	DECLARE @filegroup_name varchar(5)=(
		select isnull(max(replace(name,'AlphaRisk_filegroup','')),'01800') from sys.filegroups 
		where type='FG' and is_default='0' and data_space_id>1);

	DECLARE @function_value varchar(8)=(SELECT CONVERT(VARCHAR(8),max(value),112) FROM sys.partition_range_values);
	

	--2.判断当前日期是否需要新建数据库文件、文件组已经是否需要更新分区方案、分区函数
	--  检查文件组是否存在
	IF(SUBSTRING(@Date,2,5)>@filegroup_name)
	BEGIN
		WHILE(SUBSTRING(@Date,2,5)>@filegroup_name)
		BEGIN
			SET @filegroup_name=SUBSTRING(CONVERT(VARCHAR(8),DATEADD(MM,1,'2'+@filegroup_name+'01'),112),2,5);
			SET @SQL='alter database '+DB_NAME()+' add filegroup '+DB_NAME()+'_filegroup'+@filegroup_name;
			Exec(@SQL);
		END
	END

	--  检查数据库文件是否存在
	IF(SUBSTRING(@Date,2,5)>@database_FileName)
	BEGIN
		WHILE(SUBSTRING(@Date,2,5)>@database_FileName)
		BEGIN
			SET @database_FileName=SUBSTRING(CONVERT(VARCHAR(8),DATEADD(MM,1,'2'+@database_FileName+'01'),112),2,5);
			SET @SQL='alter database '+DB_NAME()+' add file(name=N'''+DB_NAME()+'_'+@database_FileName+''',
				filename=N''E:\WorkSpaces\02.SQLServer\DataFiles\'+DB_NAME()+'_'+@database_FileName+'.ndf'',size=5Mb,filegrowth=5Mb)
				to filegroup '+DB_NAME()+'_filegroup'+@database_FileName;
			Exec(@SQL);
		END
	END

	--  检查分区函数与分区方案中的分界值是否完整
	IF(@Date>@function_value)
	BEGIN
		WHILE(@DATE>@function_value)
		BEGIN
			SET @function_value=CONVERT(VARCHAR(8),DATEADD(MM,1,@function_value),112);
			SET @SQL='ALTER ALTER PARTITION SCHEME partSchemeByMonth NEXT USED AlphaRisk_filegroup'+SUBSTRING(@function_value,2,5);
			Exec(@SQL);
			SET @SQL='ALTER PARTITION FUNCTION partFunByMonth() SPLIT RANGE('''+@function_value+''');';
			Exec(@SQL);
		END
	END
END

/*
==========================================================================================================

ALTER PARTITION SCHEME partSchemeByMonth NEXT USED AlphaRisk_filegroup01805;
ALTER PARTITION FUNCTION partFunByMonth() SPLIT RANGE('20180401');
select $partition.partFunByMonth(rkrq),* from test order by id;
select fg.name
from sys.destination_data_spaces sp
	inner join sys.partition_schemes scm on sp.partition_scheme_id = scm.data_space_id
	inner join sys.filegroups fg on fg.data_space_id = sp.data_space_id
where scm.name='partSchemeByMonth' and sp.destination_id='4'; 


if exists (select 1
            from  sysindexes
           where  id    = object_id('TB_CIS_Prescription_Detail_V21')
            and   name  = 'Index_CIS_Prescription_Detail_V21-KH'
            and   indid > 0
            and   indid < 255)
   drop index TB_CIS_Prescription_Detail_V21."Index_CIS_Prescription_Detail_V21-KH"
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('TB_CIS_Prescription_Detail_V21')
            and   name  = 'Index_CIS_Prescription_Detail_V21-KFRQ'
            and   indid > 0
            and   indid < 255)
   drop index TB_CIS_Prescription_Detail_V21."Index_CIS_Prescription_Detail_V21-KFRQ"
go

if exists (select 1
            from  sysobjects
           where  id = object_id('TB_CIS_Prescription_Detail_V21')
            and   type = 'U')
   drop table TB_CIS_Prescription_Detail_V21
go

--==============================================================
-- Table: TB_CIS_Prescription_Detail_V21                        
--==============================================================
create table TB_CIS_Prescription_Detail_V21 (
   CYH                  VARCHAR(64)          not null,
   CFMXH                VARCHAR(64)          not null,
   YLJGDM               VARCHAR(11)          not null,
   WSJGDM               VARCHAR(22)          null,
   JZLSH                VARCHAR(32)          not null,
   CXBZ                 VARCHAR(1)           not null,
   KH                   VARCHAR(32)          not null,
   KLX                  VARCHAR(16)          not null,
   JZKSDM               VARCHAR(16)          not null,
   KFYS                 VARCHAR(16)          not null,
   KFYSXM               VARCHAR(32)          not null,
   KFYSSFZ              VARCHAR(18)          not null,
   KFRQ                 DATETIME             not null,
   XMBM                 VARCHAR(32)          not null,
   XMBMYB               VARCHAR(32)          not null,
   SCPH                 VARCHAR(32)          null,
   YXQZ                 VARCHAR(8)           null,
   XMMC                 VARCHAR(128)         not null,
   CFLX                 VARCHAR(2)           not null,
   JXDM                 VARCHAR(4)           null,
   YPGG                 VARCHAR(64)          null,
   YPYF                 VARCHAR(32)          null,
   YPSL                 NUMERIC(8,3)         null,
   YPDW                 VARCHAR(4)           null,
   CFTS                 INT                  null,
   YZZH                 VARCHAR(32)          null,
   SYPCDM               VARCHAR(32)          null,
   SYPC                 VARCHAR(32)          null,
   JL                   NUMERIC(15,3)        null,
   DW                   VARCHAR(64)          null,
   MCSL                 NUMERIC(15,3)        null,
   MCDW                 VARCHAR(64)          null,
   YF                   VARCHAR(4)           null,
   YYTS                 NUMERIC(8,3)         null,
   JYDM                 VARCHAR(4)           null,
   SFPS                 VARCHAR(1)           null,
   JCBW                 VARCHAR(32)          null,
   BZ                   VARCHAR(128)         null,
   MJ                   VARCHAR(16)          null,
   YLYL1                VARCHAR(128)         null,
   YLYL2                VARCHAR(128)         null
) 
go

alter table TB_CIS_Prescription_Detail_V21 add primary key nonclustered(cyh,cfmxh,yljgdm);

create clustered index cidx_TB_CIS_Prescription_Detail_V21 on TB_CIS_Prescription_Detail_V21(kfrq) ON partSchemeByMonth(kfrq);



--==============================================================
-- Index: "Index_CIS_Prescription_Detail_V21-KFRQ"              
--==============================================================
create index "Index_CIS_Prescription_Detail_V21-KFRQ" on TB_CIS_Prescription_Detail_V21 (
KFRQ ASC
)
go

--==============================================================
-- Index: "Index_CIS_Prescription_Detail_V21-KH"                
--==============================================================
create index "Index_CIS_Prescription_Detail_V21-KH" on TB_CIS_Prescription_Detail_V21 (
KH ASC
)
go

==========================================================================================================
*/
GO
