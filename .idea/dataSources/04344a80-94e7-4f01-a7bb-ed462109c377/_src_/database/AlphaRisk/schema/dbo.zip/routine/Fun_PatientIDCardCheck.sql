Create Function [dbo].[Fun_PatientIDCardCheck](
	@KH Varchar(18)
) Returns Char(1)
AS
Begin
	Declare @Result Char(1)='0'
	--加入卡号随手设置的情况

	--入参不合法
	If(DATALENGTH(LTRIM(RTRIM(@KH)))=0) Return @Result;

	--入参为9位数是，判断是否为社保卡
	If(DATALENGTH(@KH)=9)
	Begin
		If(LEN(@KH)=9 AND ASCII(LEFT(UPPER(@KH),1)) BETWEEN 65 AND 90)
		Set @Result='0';
	End
	
	--入参为10位时，判断是否为医保卡
	If(DATALENGTH(@KH) IN(10,28) And ISNUMERIC(@KH)=1)
	Begin
		Set @Result='1';
	End

	--入参为15位数时，判断是否为自费卡
	If(DATALENGTH(@KH)=15 And ISNUMERIC(@KH)=1)
	Begin
		Set @Result='2';
	End

	--入参为非医保、社保、自费卡时，认为为其他卡
	If(DATALENGTH(@KH) NOT IN(9,10,15,28))
	Begin
		Set @Result='9';
	End

	Return @Result;
End
GO
